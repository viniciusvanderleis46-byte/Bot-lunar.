import { pool } from "@workspace/db";
import {
  createDefaultGuildState,
  type GuildState,
} from "./types";

function parseState(value: unknown): GuildState {
  const defaults = createDefaultGuildState();
  const parsed =
    typeof value === "string"
      ? (JSON.parse(value) as Partial<GuildState>)
      : (value as Partial<GuildState> | null);

  return {
    ...defaults,
    ...parsed,
    settings: { ...defaults.settings, ...parsed?.settings },
    prices: parsed?.prices ?? defaults.prices,
    panels: parsed?.panels ?? defaults.panels,
    queues: parsed?.queues ?? defaults.queues,
    mediators: parsed?.mediators ?? defaults.mediators,
    matches: parsed?.matches ?? defaults.matches,
    stats: parsed?.stats ?? defaults.stats,
  };
}

export async function readGuildState(guildId: string): Promise<GuildState> {
  const result = await pool.query<{ state: unknown }>(
    "SELECT state FROM discord_guild_state WHERE guild_id = $1",
    [guildId],
  );
  return result.rows[0]
    ? parseState(result.rows[0].state)
    : createDefaultGuildState();
}

/**
 * Serializes each server's state changes in Postgres. The callback must not
 * perform Discord/network calls while the row lock is held.
 */
export async function updateGuildState<T>(
  guildId: string,
  update: (state: GuildState) => T,
): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      "INSERT INTO discord_guild_state (guild_id, state) VALUES ($1, $2::jsonb) ON CONFLICT (guild_id) DO NOTHING",
      [guildId, JSON.stringify(createDefaultGuildState())],
    );
    const result = await client.query<{ state: unknown }>(
      "SELECT state FROM discord_guild_state WHERE guild_id = $1 FOR UPDATE",
      [guildId],
    );
    const state = parseState(result.rows[0]?.state);
    const output = update(state);
    await client.query(
      "UPDATE discord_guild_state SET state = $2::jsonb, updated_at = NOW() WHERE guild_id = $1",
      [guildId, JSON.stringify(state)],
    );
    await client.query("COMMIT");
    return output;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}