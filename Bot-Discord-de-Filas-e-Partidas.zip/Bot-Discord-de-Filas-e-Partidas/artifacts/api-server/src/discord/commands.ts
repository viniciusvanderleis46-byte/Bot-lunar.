import { PermissionFlagsBits, SlashCommandBuilder } from "discord.js";

const platforms = [
  { name: "Mobile", value: "mob" },
  { name: "Emulador", value: "emu" },
  { name: "Misto", value: "misto" },
];

function queueCommand() {
  const command = new SlashCommandBuilder()
    .setName("fila")
    .setDescription("Publica um painel de fila");

  for (const size of [1, 2, 3] as const) {
    command.addSubcommand((subcommand) =>
      subcommand
        .setName(`${size}x${size}`)
        .setDescription(`Publica a fila ${size}x${size}`)
        .addStringOption((option) =>
          option
            .setName("plataforma")
            .setDescription("Plataforma da partida")
            .setRequired(true)
            .addChoices(...platforms),
        ),
    );
  }

  return command;
}

export const discordCommands = [
  new SlashCommandBuilder()
    .setName("config-fila")
    .setDescription("Abre o painel visual de configuração das filas")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("config-mob")
    .setDescription("Configura os valores das filas Mobile"),
  new SlashCommandBuilder()
    .setName("config-emu")
    .setDescription("Configura os valores das filas Emulador"),
  new SlashCommandBuilder()
    .setName("config-misto")
    .setDescription("Configura os valores das filas Mistas"),
  queueCommand(),
  new SlashCommandBuilder()
    .setName("config-pix")
    .setDescription("Cadastra sua chave Pix de mediador"),
  new SlashCommandBuilder()
    .setName("painel")
    .setDescription("Painéis do servidor")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("mediador")
        .setDescription("Publica o painel de disponibilidade dos mediadores"),
    ),
  new SlashCommandBuilder()
    .setName("ranking")
    .setDescription("Mostra seu perfil e o ranking do servidor"),
].map((command) => command.toJSON());