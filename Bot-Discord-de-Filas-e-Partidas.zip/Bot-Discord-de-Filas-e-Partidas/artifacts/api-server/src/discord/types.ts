export type Platform = "mob" | "emu" | "misto";
export type QueueSize = 1 | 2 | 3;
export type GelMode = "infinite" | "normal";
export type MatchStatus =
  | "confirming"
  | "waiting_mediator"
  | "waiting_payment"
  | "verifying_payment"
  | "paid"
  | "room_ready"
  | "completed"
  | "cancelled"
  | "closed";

export interface QueueEntry {
  userId: string;
  gelMode: GelMode;
}

export interface QueuePanel {
  messageId: string;
  channelId: string;
  platform: Platform;
  size: QueueSize;
}

export interface MediatorRecord {
  pixKeyCiphertext: string;
  merchantName?: string;
  merchantCity?: string;
  active: boolean;
  updatedAt: number;
}

export interface PlayerStats {
  games: number;
  wins: number;
  losses: number;
  currentStreak: number;
  bestStreak: number;
  coins: number;
}

export interface MatchRecord {
  id: string;
  threadId: string | null;
  parentChannelId: string;
  platform: Platform;
  size: QueueSize;
  gelMode: GelMode;
  players: string[];
  stakeCents: number;
  feeCents: number;
  confirmedBy: string[];
  paidBy: string[];
  moderatorId: string | null;
  status: MatchStatus;
  roomId: string | null;
  roomPassword: string | null;
  createdAt: number;
  winnerTeam: "a" | "b" | null;
}

export interface GuildState {
  settings: {
    feeCents: number;
    imageUrl: string | null;
    topicChannelId: string | null;
  };
  prices: Partial<Record<Platform, Partial<Record<QueueSize, number>>>>;
  panels: Record<string, QueuePanel>;
  queues: Record<string, QueueEntry[]>;
  mediators: Record<string, MediatorRecord>;
  matches: Record<string, MatchRecord>;
  stats: Record<string, PlayerStats>;
}

export function createDefaultGuildState(): GuildState {
  return {
    settings: {
      feeCents: 25,
      imageUrl: null,
      topicChannelId: null,
    },
    prices: {},
    panels: {},
    queues: {},
    mediators: {},
    matches: {},
    stats: {},
  };
}

export function getOrCreateStats(
  state: GuildState,
  userId: string,
): PlayerStats {
  return (state.stats[userId] ??= {
    games: 0,
    wins: 0,
    losses: 0,
    currentStreak: 0,
    bestStreak: 0,
    coins: 0,
  });
}