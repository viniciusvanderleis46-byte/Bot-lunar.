import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  ComponentType,
  EmbedBuilder,
  SeparatorSpacingSize,
  StringSelectMenuBuilder,
  type APIComponentInContainer,
  type APIContainerComponent,
  type APITextDisplayComponent,
} from "discord.js";
import { formatBRL } from "./pix";
import type {
  GelMode,
  GuildState,
  MatchRecord,
  Platform,
  PlayerStats,
  QueueEntry,
  QueuePanel,
  QueueSize,
} from "./types";

export const platformLabels: Record<Platform, string> = {
  mob: "Mobile",
  emu: "Emulador",
  misto: "Misto",
};

export const queueSizeLabels: Record<QueueSize, string> = {
  1: "1x1",
  2: "2x2",
  3: "3x3",
};

export const gelLabels: Record<GelMode, string> = {
  infinite: "Gelo Infinito",
  normal: "Gelo Normal",
};

const blue = 0x3a80ff;
const green = 0x1ca875;
const red = 0xe14754;

function textDisplay(content: string): APITextDisplayComponent {
  return { type: ComponentType.TextDisplay, content };
}

function container(
  components: APIComponentInContainer[],
  accentColor = blue,
): APIContainerComponent {
  return {
    type: ComponentType.Container,
    accent_color: accentColor,
    components,
  };
}

export function queueAdminConfigContainer(
  state: GuildState,
): APIContainerComponent {
  const priceLines = (["mob", "emu", "misto"] as const)
    .map((platform) => {
      const values = state.prices[platform];
      const price = (size: QueueSize) =>
        values?.[size] ? formatBRL(values[size]) : "não definido";
      return `• **${platformLabels[platform]}:** ${price(1)} · ${price(2)} · ${price(3)}`;
    })
    .join("\n");
  const settingsSummary = [
    `**Taxa fixa por jogador:** ${formatBRL(state.settings.feeCents)}`,
    `**Canal dos tópicos privados:** ${state.settings.topicChannelId ? `<#${state.settings.topicChannelId}>` : "não definido"}`,
    `**Imagem nos painéis:** ${state.settings.imageUrl ? "configurada" : "não configurada"}`,
    "",
    "**Valores por jogador (1x1 · 2x2 · 3x3)**",
    priceLines,
  ].join("\n");

  const settingsButtons = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("configv2:fee")
        .setLabel("Alterar taxa")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("configv2:image")
        .setLabel("Definir imagem")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("configv2:clearimage")
        .setLabel("Remover imagem")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("configv2:clearchannel")
        .setLabel("Remover canal")
        .setStyle(ButtonStyle.Secondary),
    )
    .toJSON() as APIComponentInContainer;

  const channelSelect = new ActionRowBuilder<ChannelSelectMenuBuilder>()
    .addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId("configv2:channel")
        .setPlaceholder("Selecionar canal para tópicos privados")
        .setChannelTypes(ChannelType.GuildText),
    )
    .toJSON() as APIComponentInContainer;

  const platformButtons = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("configv2:platform:mob")
        .setLabel("Valores Mobile")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("configv2:platform:emu")
        .setLabel("Valores Emulador")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("configv2:platform:misto")
        .setLabel("Valores Misto")
        .setStyle(ButtonStyle.Secondary),
    )
    .toJSON() as APIComponentInContainer;

  return container([
    textDisplay(
      "# Configuração das filas\nAjuste a taxa, os painéis e o canal onde o bot abrirá os tópicos privados das partidas.",
    ),
    {
      type: ComponentType.Separator,
      divider: true,
      spacing: SeparatorSpacingSize.Small,
    },
    textDisplay(settingsSummary),
    settingsButtons,
    channelSelect,
    {
      type: ComponentType.Separator,
      divider: true,
      spacing: SeparatorSpacingSize.Small,
    },
    textDisplay(
      "Escolha uma plataforma para cadastrar ou atualizar os valores. O bot pedirá os três valores e depois mostrará uma confirmação antes de publicar os painéis.",
    ),
    platformButtons,
  ]);
}

export function configNoticeContainer(
  title: string,
  description: string,
  accentColor = blue,
): APIContainerComponent {
  return container(
    [textDisplay(`# ${title}\n${description}`)],
    accentColor,
  );
}

export function priceConfigConfirmContainer(
  platform: Platform,
  values: Record<QueueSize, number>,
  channelId: string,
): APIContainerComponent {
  const summary = queueSizesForView
    .map(
      (size) =>
        `• **${queueSizeLabels[size]}:** ${formatBRL(values[size])} por jogador`,
    )
    .join("\n");
  const buttons = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(
          `config:publish:${platform}:${values[1]}:${values[2]}:${values[3]}:${channelId}`,
        )
        .setLabel("Confirmar e publicar")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("config:cancel")
        .setLabel("Cancelar")
        .setStyle(ButtonStyle.Secondary),
    )
    .toJSON() as APIComponentInContainer;
  return container([
    textDisplay(`# Confirmar valores — ${platformLabels[platform]}`),
    {
      type: ComponentType.Separator,
      divider: true,
      spacing: SeparatorSpacingSize.Small,
    },
    textDisplay(summary),
    textDisplay(
      `Ao confirmar, os três painéis serão publicados neste canal: <#${channelId}>.`,
    ),
    buttons,
  ]);
}

const queueSizesForView: QueueSize[] = [1, 2, 3];

export function queueEmbed(
  panel: QueuePanel,
  entries: QueueEntry[],
  state: GuildState,
): EmbedBuilder {
  const price =
    state.prices[panel.platform]?.[panel.size] ??
    0;
  const players =
    entries.length > 0
      ? entries
          .map(
            (entry, index) =>
              `${index + 1}. <@${entry.userId}> — ${gelLabels[entry.gelMode]}`,
          )
          .join("\n")
      : "Nenhum jogador na fila.";

  const embed = new EmbedBuilder()
    .setColor(blue)
    .setTitle(
      `${queueSizeLabels[panel.size]} ${platformLabels[panel.platform]} | ${formatBRL(price)}`,
    )
    .addFields({ name: "Jogadores", value: players });
  if (state.settings.imageUrl) embed.setImage(state.settings.imageUrl);
  return embed;
}

export function queueButtons() {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("queue:join:infinite")
        .setLabel("Gelo Infinito")
        .setEmoji("🧊")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("queue:join:normal")
        .setLabel("Gelo Normal")
        .setEmoji("🧊")
        .setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("queue:leave")
        .setLabel("Sair")
        .setEmoji("🚪")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

export function matchEmbed(
  match: MatchRecord,
  title: string,
): EmbedBuilder {
  const teamCapacity = match.size;
  const playerList = match.players
    .map((player, index) => `${index + 1}. <@${player}>`)
    .join("\n");
  return new EmbedBuilder()
    .setColor(blue)
    .setTitle(title)
    .setDescription(
      [
        "**Free Fire**",
        `${queueSizeLabels[match.size]} ${platformLabels[match.platform]} — ${gelLabels[match.gelMode]}`,
        "",
        "**Valores por jogador**",
        `Partida: ${formatBRL(match.stakeCents)} + taxa ${formatBRL(match.feeCents)} = ${formatBRL(match.stakeCents + match.feeCents)}`,
        `Recebe: ${formatBRL(match.stakeCents * 2)}`,
        "",
        `**Jogadores (${match.players.length}/${teamCapacity * 2})**`,
        playerList,
      ].join("\n"),
    );
}

export function confirmationButtons(matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`match:confirm:${matchId}`)
        .setLabel("Confirmar partida")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`match:cancel:${matchId}`)
        .setLabel("Cancelar")
        .setStyle(ButtonStyle.Danger),
    ),
  ];
}

export function mediatorPanelContainer(
  activeUserIds: string[],
): APIContainerComponent {
  const buttons = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId("mediator:join")
        .setLabel("Entrar")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("mediator:leave")
        .setLabel("Sair")
        .setStyle(ButtonStyle.Secondary),
    )
    .toJSON() as APIComponentInContainer;

  return container([
    textDisplay(
      "# Painel de mediadores\nUse **Entrar** para ficar disponível e ser selecionado para partidas. Use **Sair** para pausar os chamados.",
    ),
    {
      type: ComponentType.Separator,
      divider: true,
      spacing: SeparatorSpacingSize.Small,
    },
    textDisplay(
      `**Disponíveis agora**\n${activeUserIds.length ? activeUserIds.map((userId) => `• <@${userId}>`).join("\n") : "Nenhum mediador disponível."}`,
    ),
    buttons,
  ]);
}

export function rankingMenuEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(blue)
    .setTitle("Seu Perfil e Ranking")
    .setDescription(
      "Veja seu perfil e o ranking do servidor através dos botões abaixo.",
    );
}

export function rankingMenuButtons() {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("ranking:profile")
        .setLabel("Seu Perfil")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("ranking:show")
        .setLabel("Ranking")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

export function profileEmbed(
  displayName: string,
  stats: PlayerStats,
): EmbedBuilder {
  const winRate =
    stats.games === 0 ? 0 : (stats.wins / stats.games) * 100;
  const kdr =
    stats.losses === 0
      ? stats.wins > 0
        ? "∞"
        : "0.00"
      : (stats.wins / stats.losses).toFixed(2);

  return new EmbedBuilder()
    .setColor(blue)
    .setTitle(`Estatísticas de ${displayName}`)
    .setDescription(
      [
        `Partidas: ${stats.games}`,
        `Vitórias: ${stats.wins} | Derrotas: ${stats.losses}`,
        "",
        `KDR: ${kdr} | Win Rate: ${winRate.toFixed(2)}%`,
        "",
        `Maior sequência de vitórias: ${stats.bestStreak}`,
        "",
        `Coins: ${stats.coins}`,
      ].join("\n"),
    );
}

export function rankingEmbed(
  state: GuildState,
  viewerId: string,
  page: number,
): EmbedBuilder {
  const players = Object.entries(state.stats)
    .filter(([, stats]) => stats.games > 0)
    .sort(
      ([idA, statsA], [idB, statsB]) =>
        statsB.wins - statsA.wins ||
        statsB.coins - statsA.coins ||
        idA.localeCompare(idB),
    );
  const start = page * 10;
  const visible = players.slice(start, start + 10);
  const lines = visible.length
    ? visible.map(
        ([userId, stats], index) =>
          `**${start + index + 1}.** <@${userId}> — **Vitórias:** ${stats.wins}`,
      )
    : ["Ainda não há partidas concluídas no ranking."];
  const viewerIndex = players.findIndex(([userId]) => userId === viewerId);
  const maxPage = Math.max(0, Math.ceil(players.length / 10) - 1);

  return new EmbedBuilder()
    .setColor(blue)
    .setTitle("Ranking de Jogadores")
    .setDescription(
      [
        ...lines,
        "",
        "**Tipo**",
        "Vitórias",
        "",
        "**Sua Posição**",
        viewerIndex < 0 ? "—" : `#${viewerIndex + 1}`,
        "",
        `Página ${page + 1}/${maxPage + 1}`,
      ].join("\n"),
    );
}

export function rankingPageButtons(page: number, total: number) {
  const lastPage = Math.max(0, Math.ceil(total / 10) - 1);
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`ranking:prev:${page}`)
        .setLabel("◀")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page <= 0),
      new ButtonBuilder()
        .setCustomId("ranking:page")
        .setLabel(`${page + 1}/${lastPage + 1}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true),
      new ButtonBuilder()
        .setCustomId(`ranking:next:${page}`)
        .setLabel("▶")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page >= lastPage),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("ranking:menu")
        .setLabel("Voltar")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

export function mediatorReleaseButton(matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`pix:release:${matchId}`)
        .setLabel("Liberar chave Pix")
        .setStyle(ButtonStyle.Success),
    ),
  ];
}

export function paymentButtons(matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`pix:copy:${matchId}`)
        .setLabel("Copiar Pix")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`payment:confirm:${matchId}`)
        .setLabel("Já paguei")
        .setStyle(ButtonStyle.Success),
    ),
  ];
}

export function verifyPaymentButton(matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`payment:verify:${matchId}`)
        .setLabel("Confirmar recebimento")
        .setStyle(ButtonStyle.Success),
    ),
  ];
}

export function roomButtons(matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`room:copyid:${matchId}`)
        .setLabel("Copiar ID")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`room:copypass:${matchId}`)
        .setLabel("Copiar senha")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

export function matchControlButtons(guildId: string, matchId: string) {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`v:finish:${guildId}:${matchId}`)
        .setLabel("Terminar")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`v:winner:${guildId}:${matchId}`)
        .setLabel("Ganhador")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`v:rematch:${guildId}:${matchId}`)
        .setLabel("Revanche")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

export function winnerSelect(
  guildId: string,
  match: MatchRecord,
): ActionRowBuilder<StringSelectMenuBuilder> {
  const firstTeam = match.players.slice(0, match.size);
  const secondTeam = match.players.slice(match.size);
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`v:winner-select:${guildId}:${match.id}`)
      .setPlaceholder("Selecione o time vencedor")
      .addOptions([
        {
          label: "Equipe 1",
          value: "a",
          description: firstTeam.map((id) => `<@${id}>`).join(" "),
        },
        {
          label: "Equipe 2",
          value: "b",
          description: secondTeam.map((id) => `<@${id}>`).join(" "),
        },
      ]),
  );
}

export function matchResultEmbed(
  match: MatchRecord,
  winner: "a" | "b",
): EmbedBuilder {
  const winnerPlayers =
    winner === "a"
      ? match.players.slice(0, match.size)
      : match.players.slice(match.size);
  const losingPlayers =
    winner === "a"
      ? match.players.slice(match.size)
      : match.players.slice(0, match.size);
  return new EmbedBuilder()
    .setColor(green)
    .setTitle("Partida finalizada")
    .setDescription(
      [
        `**Vencedores:** ${winnerPlayers.map((id) => `<@${id}>`).join(", ")}`,
        `**Derrotados:** ${losingPlayers.map((id) => `<@${id}>`).join(", ")}`,
        "",
        "As vitórias e coins foram atualizados.",
      ].join("\n"),
    );
}

export function cancelledMatchEmbed() {
  return new EmbedBuilder()
    .setColor(red)
    .setTitle("Partida cancelada")
    .setDescription("Um participante cancelou a partida.");
}