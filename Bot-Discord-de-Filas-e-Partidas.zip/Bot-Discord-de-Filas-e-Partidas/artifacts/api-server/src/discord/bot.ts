import { randomInt, randomUUID } from "node:crypto";
import {
  ActionRowBuilder,
  type AnyThreadChannel,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuInteraction,
  ChannelType,
  ChatInputCommandInteraction,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  GuildMember,
  Interaction,
  Message,
  ModalBuilder,
  MessageFlags,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextChannel,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import { logger } from "../lib/logger";
import { discordCommands } from "./commands";
import {
  createPixPayload,
  createPixQrCode,
  decryptPixKey,
  encryptPixKey,
  formatBRL,
  parseBrazilianMoneyToCents,
} from "./pix";
import { readGuildState, updateGuildState } from "./store";
import {
  createDefaultGuildState,
  getOrCreateStats,
  type GelMode,
  type GuildState,
  type MatchRecord,
  type Platform,
  type QueueEntry,
  type QueuePanel,
  type QueueSize,
} from "./types";
import {
  cancelledMatchEmbed,
  configNoticeContainer,
  confirmationButtons,
  gelLabels,
  matchControlButtons,
  matchEmbed,
  matchResultEmbed,
  mediatorPanelContainer,
  mediatorReleaseButton,
  paymentButtons,
  platformLabels,
  priceConfigConfirmContainer,
  profileEmbed,
  queueAdminConfigContainer,
  queueButtons,
  queueEmbed,
  queueSizeLabels,
  rankingEmbed,
  rankingMenuButtons,
  rankingMenuEmbed,
  rankingPageButtons,
  roomButtons,
  verifyPaymentButton,
  winnerSelect,
} from "./views";

const queueSizes: QueueSize[] = [1, 2, 3];

function isPlatform(value: string | null): value is Platform {
  return value === "mob" || value === "emu" || value === "misto";
}

function isQueueSize(value: number): value is QueueSize {
  return value === 1 || value === 2 || value === 3;
}

function isActiveMatch(match: MatchRecord): boolean {
  return !["completed", "cancelled", "closed"].includes(match.status);
}

function hasAdminPermissions(member: GuildMember): boolean {
  return (
    member.permissions.has(PermissionsBitField.Flags.Administrator) ||
    member.permissions.has(PermissionsBitField.Flags.ManageGuild)
  );
}

async function fetchMember(interaction: Interaction): Promise<GuildMember | null> {
  if (!interaction.guild) return null;
  try {
    return await interaction.guild.members.fetch(interaction.user.id);
  } catch {
    return null;
  }
}

async function requireAdmin(interaction: Interaction): Promise<boolean> {
  const member = await fetchMember(interaction);
  if (member && hasAdminPermissions(member)) return true;
  if (interaction.isRepliable()) {
    await interaction.reply({
      content: "Este comando é apenas para administradores do servidor.",
      ephemeral: true,
    });
  }
  return false;
}

async function requireMediator(interaction: Interaction): Promise<boolean> {
  const member = await fetchMember(interaction);
  const mediatorRole = member?.roles.cache.some((role) =>
    role.name.toLocaleLowerCase("pt-BR").includes("mediador"),
  );
  if (member && (hasAdminPermissions(member) || mediatorRole)) return true;
  if (interaction.isRepliable()) {
    await interaction.reply({
      content:
        "É necessário ter um cargo com “mediador” no nome para usar este comando.",
      ephemeral: true,
    });
  }
  return false;
}

function activeMediatorIds(state: GuildState): string[] {
  return Object.entries(state.mediators)
    .filter(([, mediator]) => mediator.active && mediator.pixKeyCiphertext)
    .map(([userId]) => userId);
}

function chooseMediator(state: GuildState): string | null {
  const eligible = activeMediatorIds(state);
  if (eligible.length === 0) return null;
  return eligible[randomInt(eligible.length)] ?? null;
}

function publicError(error: unknown): string {
  return error instanceof Error
    ? error.message
    : "Ocorreu um erro ao processar esta ação.";
}

function assertGuild(
  interaction: Interaction,
): asserts interaction is Interaction & { guildId: string; guild: NonNullable<Interaction["guild"]> } {
  if (!interaction.guildId || !interaction.guild) {
    throw new Error("Este comando só pode ser usado dentro de um servidor.");
  }
}

function parsePlatformCommand(commandName: string): Platform | null {
  if (commandName === "config-mob") return "mob";
  if (commandName === "config-emu") return "emu";
  if (commandName === "config-misto") return "misto";
  return null;
}

async function handleConfigFila(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!(await requireAdmin(interaction))) return;
  if (!interaction.isChatInputCommand()) return;
  const state = await readGuildState(interaction.guildId);
  await interaction.reply({
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    components: [queueAdminConfigContainer(state)],
  });
}

async function handlePriceConfig(
  interaction: ChatInputCommandInteraction | ButtonInteraction,
  platform: Platform,
): Promise<void> {
  if (!(await requireAdmin(interaction))) return;

  const modal = new ModalBuilder()
    .setCustomId(`prices:${platform}`)
    .setTitle(`Valores das filas — ${platformLabels[platform]}`);

  for (const size of queueSizes) {
    const input = new TextInputBuilder()
      .setCustomId(`price_${size}`)
      .setLabel(`${queueSizeLabels[size]} — valor por jogador (R$)`)
      .setPlaceholder("Exemplo: 0,50")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(12);
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(input),
    );
  }

  await interaction.showModal(modal);
}

async function handlePriceModal(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!interaction.isModalSubmit()) return;
  const platformValue = interaction.customId.split(":")[1] ?? "";
  if (!isPlatform(platformValue)) return;
  if (!(await requireAdmin(interaction))) return;

  const values = {} as Record<QueueSize, number>;
  for (const size of queueSizes) {
    const cents = parseBrazilianMoneyToCents(
      interaction.fields.getTextInputValue(`price_${size}`),
    );
    if (cents === null) {
      await interaction.reply({
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        components: [
          configNoticeContainer(
            "Valor inválido",
            `Informe um valor válido para ${queueSizeLabels[size]}, como 0,50.`,
            0xe14754,
          ),
        ],
      });
      return;
    }
    values[size] = cents;
  }

  if (!interaction.channelId) {
    await interaction.reply({
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Canal não encontrado",
          "Execute o comando em um canal de texto antes de configurar os valores.",
          0xe14754,
        ),
      ],
    });
    return;
  }
  await interaction.reply({
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    components: [
      priceConfigConfirmContainer(
        platformValue,
        values,
        interaction.channelId,
      ),
    ],
  });
}

async function handleAdminPanelButton(
  interaction: ButtonInteraction,
  action: string,
  rest: string[],
): Promise<void> {
  assertGuild(interaction);
  if (action === "platform") {
    const platform = rest[0];
    if (!platform || !isPlatform(platform)) {
      await interaction.reply({
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        components: [
          configNoticeContainer(
            "Plataforma inválida",
            "Abra novamente o painel e selecione uma plataforma.",
            0xe14754,
          ),
        ],
      });
      return;
    }
    await handlePriceConfig(interaction, platform);
    return;
  }
  if (!(await requireAdmin(interaction))) return;

  if (action === "fee" || action === "image") {
    const isFee = action === "fee";
    const modal = new ModalBuilder()
      .setCustomId(`configv2:${action}`)
      .setTitle(isFee ? "Taxa fixa por jogador" : "Imagem dos painéis");
    const input = new TextInputBuilder()
      .setCustomId(isFee ? "fee_cents" : "image_url")
      .setLabel(
        isFee
          ? "Taxa em centavos (0 a 100000)"
          : "URL pública (vazio remove)",
      )
      .setPlaceholder(isFee ? "25" : "https://exemplo.com/imagem.png")
      .setStyle(TextInputStyle.Short)
      .setRequired(isFee)
      .setMaxLength(isFee ? 6 : 512);
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(input),
    );
    await interaction.showModal(modal);
    return;
  }

  if (action === "clearimage" || action === "clearchannel") {
    const state = await updateGuildState(interaction.guildId, (guildState) => {
      if (action === "clearimage") guildState.settings.imageUrl = null;
      else guildState.settings.topicChannelId = null;
      return guildState;
    });
    await interaction.update({
      flags: MessageFlags.IsComponentsV2,
      components: [queueAdminConfigContainer(state)],
    });
  }
}

async function handleConfigSettingModal(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!interaction.isModalSubmit()) return;
  if (!(await requireAdmin(interaction))) return;

  const setting = interaction.customId.split(":")[1];
  if (setting === "fee") {
    const rawFee = interaction.fields.getTextInputValue("fee_cents").trim();
    const feeCents = /^\d{1,6}$/.test(rawFee) ? Number(rawFee) : -1;
    if (!Number.isSafeInteger(feeCents) || feeCents < 0 || feeCents > 100000) {
      await interaction.reply({
        flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
        components: [
          configNoticeContainer(
            "Taxa inválida",
            "Informe um número inteiro de centavos entre 0 e 100000.",
            0xe14754,
          ),
        ],
      });
      return;
    }
    await updateGuildState(interaction.guildId, (state) => {
      state.settings.feeCents = feeCents;
    });
  } else if (setting === "image") {
    const imageUrl = interaction.fields.getTextInputValue("image_url").trim();
    if (imageUrl) {
      try {
        const parsedUrl = new URL(imageUrl);
        if (parsedUrl.protocol !== "https:" && parsedUrl.protocol !== "http:") {
          throw new Error("invalid protocol");
        }
      } catch {
        await interaction.reply({
          flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
          components: [
            configNoticeContainer(
              "URL inválida",
              "Informe uma URL pública iniciada por http:// ou https://, ou deixe o campo vazio para remover a imagem.",
              0xe14754,
            ),
          ],
        });
        return;
      }
    }
    await updateGuildState(interaction.guildId, (state) => {
      state.settings.imageUrl = imageUrl || null;
    });
  } else {
    return;
  }

  const state = await readGuildState(interaction.guildId);
  await interaction.reply({
    flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
    components: [queueAdminConfigContainer(state)],
  });
}

async function handleConfigChannelSelect(
  interaction: ChannelSelectMenuInteraction,
): Promise<void> {
  assertGuild(interaction);
  if (!(await requireAdmin(interaction))) return;
  const channelId = interaction.values[0];
  const channel = channelId
    ? await interaction.guild.channels.fetch(channelId).catch(() => null)
    : null;
  if (!(channel instanceof TextChannel)) {
    await interaction.reply({
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Canal inválido",
          "Selecione um canal de texto deste servidor.",
          0xe14754,
        ),
      ],
    });
    return;
  }
  await updateGuildState(interaction.guildId, (state) => {
    state.settings.topicChannelId = channel.id;
  });
  const state = await readGuildState(interaction.guildId);
  await interaction.update({
    flags: MessageFlags.IsComponentsV2,
    components: [queueAdminConfigContainer(state)],
  });
}

async function postQueuePanel(
  guildId: string,
  channel: TextChannel,
  platform: Platform,
  size: QueueSize,
): Promise<void> {
  const state = await readGuildState(guildId);
  const price = state.prices[platform]?.[size];
  if (!price) {
    throw new Error(
      `Configure primeiro os valores de ${platformLabels[platform]} com /config-${platform}.`,
    );
  }
  const panelDraft: QueuePanel = {
    messageId: "",
    channelId: channel.id,
    platform,
    size,
  };
  const message = await channel.send({
    embeds: [queueEmbed(panelDraft, [], state)],
    components: queueButtons(),
  });
  await updateGuildState(guildId, (guildState) => {
    guildState.panels[message.id] = { ...panelDraft, messageId: message.id };
    guildState.queues[message.id] = [];
  });
}

async function handleFilaCommand(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!interaction.isChatInputCommand()) return;
  const selectedPlatform = interaction.options.getString("plataforma");
  if (!isPlatform(selectedPlatform)) {
    await interaction.reply({
      content: "Escolha uma plataforma válida.",
      ephemeral: true,
    });
    return;
  }
  const subcommand = interaction.options.getSubcommand();
  const size = Number(subcommand[0]);
  if (!isQueueSize(size)) {
    await interaction.reply({
      content: "Escolha um tamanho de fila válido.",
      ephemeral: true,
    });
    return;
  }
  if (!interaction.channel || !(interaction.channel instanceof TextChannel)) {
    await interaction.reply({
      content: "Use este comando em um canal de texto.",
      ephemeral: true,
    });
    return;
  }

  try {
    await postQueuePanel(
      interaction.guildId,
      interaction.channel,
      selectedPlatform,
      size,
    );
    await interaction.reply({
      content: `Painel ${queueSizeLabels[size]} ${platformLabels[selectedPlatform]} publicado.`,
      ephemeral: true,
    });
  } catch (error) {
    await interaction.reply({ content: publicError(error), ephemeral: true });
  }
}

async function publishConfiguredPanels(
  guildId: string,
  channel: TextChannel,
  platform: Platform,
  values: Record<QueueSize, number>,
): Promise<void> {
  await updateGuildState(guildId, (state) => {
    state.prices[platform] = values;
  });
  const sortedSizes = [...queueSizes].sort(
    (left, right) => values[right] - values[left],
  );
  for (const size of sortedSizes) {
    await postQueuePanel(guildId, channel, platform, size);
  }
}

async function startMatchThread(
  client: Client,
  guildId: string,
  matchId: string,
  matchSnapshot: MatchRecord,
): Promise<void> {
  const guild = await client.guilds.fetch(guildId);
  const parent = await guild.channels.fetch(matchSnapshot.parentChannelId);
  if (!(parent instanceof TextChannel)) {
    throw new Error("O canal configurado para tópicos não está disponível.");
  }

  const thread = await parent.threads.create({
    name: `partida-${queueSizeLabels[matchSnapshot.size]}-${platformLabels[matchSnapshot.platform]}-${matchId.slice(0, 6)}`.toLocaleLowerCase(
      "pt-BR",
    ),
    type: ChannelType.PrivateThread,
    invitable: false,
    autoArchiveDuration: 10080,
    reason: "Partida formada pela fila do bot",
  });

  try {
    await Promise.all(
      matchSnapshot.players.map((userId) => thread.members.add(userId)),
    );
    await updateGuildState(guildId, (state) => {
      const match = state.matches[matchId];
      if (match) match.threadId = thread.id;
    });
    await thread.send({
      content: matchSnapshot.players.map((userId) => `<@${userId}>`).join(" "),
      embeds: [matchEmbed(matchSnapshot, "Aguardando confirmação")],
      components: confirmationButtons(matchId),
    });
  } catch (error) {
    await thread.delete("Falha ao preparar a partida").catch(() => undefined);
    throw error;
  }
}

async function handleQueueButton(
  client: Client,
  interaction: ButtonInteraction,
  action: string,
): Promise<void> {
  assertGuild(interaction);
  await interaction.deferReply({ ephemeral: true });
  const messageId = interaction.message.id;
  const matchId = randomUUID();
  const result = await updateGuildState(interaction.guildId, (state) => {
    const panel = state.panels[messageId];
    if (!panel) return { error: "Este painel de fila não está mais ativo." };

    const parentChannelId = state.settings.topicChannelId;
    if (!parentChannelId) {
      return {
        error:
          "O administrador precisa configurar o canal de tópicos com /config-fila.",
      };
    }
    const queue = (state.queues[messageId] ??= []);
    if (action === "leave") {
      const originalLength = queue.length;
      state.queues[messageId] = queue.filter(
        (entry) => entry.userId !== interaction.user.id,
      );
      return originalLength === state.queues[messageId]?.length
        ? { error: "Você não está nesta fila." }
        : { panel, entries: state.queues[messageId] ?? [], left: true };
    }

    const gelMode = action === "infinite" ? "infinite" : "normal";
    if (
      Object.values(state.queues).some((entries) =>
        entries.some((entry) => entry.userId === interaction.user.id),
      )
    ) {
      return { error: "Você já está em uma fila do servidor." };
    }
    if (
      Object.values(state.matches).some(
        (match) => isActiveMatch(match) && match.players.includes(interaction.user.id),
      )
    ) {
      return { error: "Você já está em uma partida ativa." };
    }

    queue.push({ userId: interaction.user.id, gelMode });
    const matchPlayersNeeded = panel.size * 2;
    const sameModeEntries = queue.filter((entry) => entry.gelMode === gelMode);
    if (sameModeEntries.length < matchPlayersNeeded) {
      return { panel, entries: queue, joined: true };
    }

    const matchedPlayers = sameModeEntries.slice(0, matchPlayersNeeded);
    const matchedIds = new Set(matchedPlayers.map((entry) => entry.userId));
    state.queues[messageId] = queue.filter(
      (entry) => !matchedIds.has(entry.userId),
    );
    const stakeCents = state.prices[panel.platform]?.[panel.size];
    if (!stakeCents) {
      state.queues[messageId].push(...matchedPlayers);
      return {
        error: "O administrador precisa configurar o valor desta fila.",
      };
    }
    const match: MatchRecord = {
      id: matchId,
      threadId: null,
      parentChannelId,
      platform: panel.platform,
      size: panel.size,
      gelMode,
      players: matchedPlayers.map((entry) => entry.userId),
      stakeCents,
      feeCents: state.settings.feeCents,
      confirmedBy: [],
      paidBy: [],
      moderatorId: null,
      status: "confirming",
      roomId: null,
      roomPassword: null,
      createdAt: Date.now(),
      winnerTeam: null,
    };
    state.matches[matchId] = match;
    return {
      panel,
      entries: state.queues[messageId],
      joined: true,
      match: { ...match },
    };
  });

  if ("error" in result && result.error) {
    await interaction.editReply(result.error);
    return;
  }
  if (
    !("panel" in result) ||
    !result.panel ||
    !("entries" in result) ||
    !result.entries
  ) {
    await interaction.editReply("Não foi possível atualizar essa fila.");
    return;
  }

  const latestState = await readGuildState(interaction.guildId);
  await interaction.message.edit({
    embeds: [queueEmbed(result.panel, result.entries, latestState)],
    components: queueButtons(),
  });

  if ("left" in result && result.left) {
    await interaction.editReply("Você saiu da fila.");
    return;
  }
  if ("match" in result && result.match) {
    try {
      await startMatchThread(client, interaction.guildId, matchId, result.match);
      await interaction.editReply(
        "Fila completa. Criei um tópico privado para os jogadores confirmarem.",
      );
    } catch (error) {
      await updateGuildState(interaction.guildId, (state) => {
        const failedMatch = state.matches[matchId];
        if (!failedMatch) return;
        state.queues[messageId] ??= [];
        state.queues[messageId].push(
          ...failedMatch.players.map((userId) => ({
            userId,
            gelMode: failedMatch.gelMode,
          })),
        );
        delete state.matches[matchId];
      });
      const restored = await readGuildState(interaction.guildId);
      await interaction.message.edit({
        embeds: [
          queueEmbed(
            result.panel,
            restored.queues[messageId] ?? [],
            restored,
          ),
        ],
        components: queueButtons(),
      });
      await interaction.editReply(
        `Não consegui criar o tópico. A fila foi restaurada. ${publicError(error)}`,
      );
    }
    return;
  }
  await interaction.editReply(
    `Você entrou em ${gelLabels[action === "infinite" ? "infinite" : "normal"]}. A fila está aguardando mais jogadores do mesmo modo.`,
  );
}

async function assignUnassignedMatches(
  client: Client,
  guildId: string,
): Promise<void> {
  const assignedIds = await updateGuildState(guildId, (state) => {
    const active = activeMediatorIds(state);
    if (!active.length) return [];
    const assignments: string[] = [];
    for (const match of Object.values(state.matches)) {
      if (match.status !== "waiting_mediator" || match.moderatorId) continue;
      match.moderatorId = active[randomInt(active.length)] ?? null;
      if (match.moderatorId) assignments.push(match.id);
    }
    return assignments;
  });
  for (const matchId of assignedIds) {
    await sendMediatorAssignment(client, guildId, matchId);
  }
}

async function sendMediatorAssignment(
  client: Client,
  guildId: string,
  matchId: string,
): Promise<void> {
  const state = await readGuildState(guildId);
  const match = state.matches[matchId];
  if (!match?.threadId || !match.moderatorId) return;
  const thread = await client.channels.fetch(match.threadId).catch(() => null);
  if (!(thread instanceof TextChannel) && !thread?.isThread()) return;
  await thread.send({
    content: `<@${match.moderatorId}>`,
    embeds: [
      new EmbedBuilder()
        .setColor(0x3a80ff)
        .setTitle("Aguardando mediador")
        .setDescription(
          `Aguardando <@${match.moderatorId}> liberar a chave para pagamento.`,
        ),
    ],
    components: mediatorReleaseButton(matchId),
  });
}

async function completeConfirmations(
  client: Client,
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  const update = await updateGuildState(interaction.guildId, (state) => {
    const match = state.matches[matchId];
    if (!match || match.status !== "confirming") {
      return { error: "Esta partida não está mais aguardando confirmação." };
    }
    if (!match.players.includes(interaction.user.id)) {
      return { error: "Somente os jogadores desta partida podem confirmar." };
    }
    if (match.confirmedBy.includes(interaction.user.id)) {
      return { error: "Você já confirmou esta partida." };
    }
    match.confirmedBy.push(interaction.user.id);
    const allConfirmed = match.confirmedBy.length === match.players.length;
    if (allConfirmed) {
      match.status = "waiting_mediator";
      match.moderatorId = chooseMediator(state);
    }
    return {
      match: { ...match, players: [...match.players], confirmedBy: [...match.confirmedBy] },
      allConfirmed,
    };
  });
  if ("error" in update && update.error) {
    await interaction.reply({ content: update.error, ephemeral: true });
    return;
  }
  if (!("match" in update) || !update.match) return;

  await interaction.reply({
    content: update.allConfirmed
      ? "Todos confirmaram. A partida foi encaminhada para a mediação."
      : "Confirmação registrada.",
    ephemeral: true,
  });

  if (update.allConfirmed) {
    await interaction.message.edit({
      embeds: [matchEmbed(update.match, "Aguardando mediador")],
      components: [],
    });
    if (update.match.moderatorId) {
      await sendMediatorAssignment(client, interaction.guildId, matchId);
    } else if (update.match.threadId) {
      const thread = await client.channels.fetch(update.match.threadId).catch(() => null);
      if (thread?.isThread()) {
        await thread.send(
          "Ainda não há mediadores disponíveis. Um mediador será chamado quando entrar no painel.",
        );
      }
    }
  } else {
    await interaction.message.edit({
      embeds: [
        matchEmbed(
          update.match,
          `Aguardando confirmação (${update.match.confirmedBy.length}/${update.match.players.length})`,
        ),
      ],
    });
  }
}

async function handleMatchCancel(
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  const result = await updateGuildState(interaction.guildId, (state) => {
    const match = state.matches[matchId];
    if (!match || match.status !== "confirming") {
      return { error: "Esta partida não pode mais ser cancelada por este botão." };
    }
    if (!match.players.includes(interaction.user.id)) {
      return { error: "Somente os jogadores desta partida podem cancelar." };
    }
    match.status = "cancelled";
    return { match: { ...match } };
  });
  if ("error" in result && result.error) {
    await interaction.reply({ content: result.error, ephemeral: true });
    return;
  }
  await interaction.update({
    embeds: [cancelledMatchEmbed()],
    components: [],
  });
}

async function handleMediatorPanel(
  interaction: ChatInputCommandInteraction & { guildId: string },
): Promise<void> {
  if (!(await requireMediator(interaction))) return;
  const state = await readGuildState(interaction.guildId);
  await interaction.reply({
    flags: MessageFlags.IsComponentsV2,
    components: [mediatorPanelContainer(activeMediatorIds(state))],
  });
}

async function handleMediatorToggle(
  client: Client,
  interaction: ButtonInteraction,
  entering: boolean,
): Promise<void> {
  assertGuild(interaction);
  if (!(await requireMediator(interaction))) return;
  const result = await updateGuildState(interaction.guildId, (state) => {
    const mediator = state.mediators[interaction.user.id];
    if (entering && !mediator?.pixKeyCiphertext) {
      return { error: "Cadastre sua chave primeiro com /config-pix." };
    }
    if (!mediator) {
      state.mediators[interaction.user.id] = {
        pixKeyCiphertext: "",
        active: false,
        updatedAt: Date.now(),
      };
    }
    state.mediators[interaction.user.id]!.active = entering;
    state.mediators[interaction.user.id]!.updatedAt = Date.now();
    return { activeIds: activeMediatorIds(state) };
  });
  if ("error" in result && result.error) {
    await interaction.reply({ content: result.error, ephemeral: true });
    return;
  }
  if (!("activeIds" in result) || !Array.isArray(result.activeIds)) return;
  await interaction.update({
    flags: MessageFlags.IsComponentsV2,
    components: [mediatorPanelContainer(result.activeIds)],
  });
  if (entering) {
    await assignUnassignedMatches(client, interaction.guildId);
  }
}

async function handlePixCommand(
  interaction: ChatInputCommandInteraction & { guildId: string },
): Promise<void> {
  if (!(await requireMediator(interaction))) return;
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(0x3a80ff)
        .setTitle("Chave Pix do mediador")
        .setDescription(
          "Cadastre sua chave Pix pelo botão. O formulário é privado e a chave nunca aparece nesta mensagem pública.",
        ),
    ],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("pix:register")
          .setLabel("Cadastrar chave Pix")
          .setStyle(ButtonStyle.Primary),
      ),
    ],
  });
}

async function handlePixModal(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!interaction.isModalSubmit()) return;
  if (!(await requireMediator(interaction))) return;
  const key = interaction.fields.getTextInputValue("pix_key").trim();
  const merchantName = interaction.fields.getTextInputValue("merchant_name").trim();
  const merchantCity = interaction.fields.getTextInputValue("merchant_city").trim();
  if (Buffer.byteLength(key, "utf8") < 3 || Buffer.byteLength(key, "utf8") > 77) {
    await interaction.reply({
      content: "A chave Pix deve ter entre 3 e 77 bytes.",
      ephemeral: true,
    });
    return;
  }
  if (
    Buffer.byteLength(merchantName, "utf8") < 1 ||
    Buffer.byteLength(merchantName, "utf8") > 25 ||
    Buffer.byteLength(merchantCity, "utf8") < 1 ||
    Buffer.byteLength(merchantCity, "utf8") > 15
  ) {
    await interaction.reply({
      content:
        "Informe o nome do recebedor (até 25 bytes) e a cidade (até 15 bytes) conforme aparecem no Pix.",
      ephemeral: true,
    });
    return;
  }
  await updateGuildState(interaction.guildId, (state) => {
    const existing = state.mediators[interaction.user.id];
    state.mediators[interaction.user.id] = {
      pixKeyCiphertext: encryptPixKey(key),
      merchantName,
      merchantCity,
      active: existing?.active ?? false,
      updatedAt: Date.now(),
    };
  });
  await interaction.reply({
    content:
      "Chave Pix cadastrada com proteção criptográfica. Ela só será usada nas partidas em que você for selecionado.",
    ephemeral: true,
  });
}

async function handlePixRelease(
  client: Client,
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  await interaction.deferReply({ ephemeral: true });
  const reservation = await updateGuildState(interaction.guildId, (state) => {
    const match = state.matches[matchId];
    if (
      !match ||
      match.status !== "waiting_mediator" ||
      match.moderatorId !== interaction.user.id
    ) {
      return { error: "Esta partida não está atribuída a você para liberar o Pix." };
    }
    const mediator = state.mediators[interaction.user.id];
    if (!mediator?.pixKeyCiphertext) {
      return { error: "Cadastre sua chave novamente com /config-pix." };
    }
    match.status = "waiting_payment";
    return {
      match: { ...match },
      encryptedKey: mediator.pixKeyCiphertext,
      merchantName: mediator.merchantName ?? "MEDIADOR",
      merchantCity: mediator.merchantCity ?? "SAO PAULO",
    };
  });
  if ("error" in reservation && reservation.error) {
    await interaction.editReply(reservation.error);
    return;
  }
  if (!("match" in reservation) || !reservation.match || !reservation.encryptedKey) {
    await interaction.editReply("Não foi possível liberar o Pix.");
    return;
  }

  try {
    const pixKey = decryptPixKey(reservation.encryptedKey);
    const payload = createPixPayload(
      pixKey,
      reservation.match.stakeCents + reservation.match.feeCents,
      reservation.merchantName,
      reservation.merchantCity,
    );
    const qr = await createPixQrCode(payload);
    const thread = reservation.match.threadId
      ? await client.channels.fetch(reservation.match.threadId).catch(() => null)
      : null;
    if (!thread?.isThread()) throw new Error("O tópico desta partida não foi encontrado.");

    await thread.send({
      embeds: [
        new EmbedBuilder()
          .setColor(0x3a80ff)
          .setTitle("Pagamento Pix")
          .setDescription(
            [
              `Cada jogador deve pagar **${formatBRL(reservation.match.stakeCents + reservation.match.feeCents)}**.`,
              `Taxa incluída: ${formatBRL(reservation.match.feeCents)} por jogador.`,
              "",
              "Escaneie o QR Code ou use **Copiar Pix**.",
              "O pagamento não é confirmado automaticamente. Marque **Já paguei** após pagar; o mediador deve conferir o recebimento.",
            ].join("\n"),
          )
          .setImage("attachment://pix.png"),
      ],
      files: [new AttachmentBuilder(qr, { name: "pix.png" })],
      components: paymentButtons(matchId),
    });
    await interaction.editReply("Chave Pix liberada no tópico da partida.");
  } catch (error) {
    await updateGuildState(interaction.guildId, (state) => {
      const match = state.matches[matchId];
      if (match?.status === "waiting_payment") match.status = "waiting_mediator";
    });
    await interaction.editReply(publicError(error));
  }
}

async function createPixForMatch(
  guildId: string,
  matchId: string,
): Promise<{ payload: string; match: MatchRecord }> {
  const state = await readGuildState(guildId);
  const match = state.matches[matchId];
  if (
    !match ||
    !["waiting_payment", "verifying_payment", "paid"].includes(match.status)
  ) {
    throw new Error("O Pix desta partida ainda não foi liberado.");
  }
  if (!match.players.includes(match.players[0] ?? "")) {
    throw new Error("Jogadores da partida inválidos.");
  }
  if (!match.moderatorId) throw new Error("Não há mediador associado à partida.");
  const mediator = state.mediators[match.moderatorId];
  const encryptedKey = mediator?.pixKeyCiphertext;
  if (!encryptedKey) throw new Error("A chave Pix do mediador não está cadastrada.");
  return {
    payload: createPixPayload(
      decryptPixKey(encryptedKey),
      match.stakeCents + match.feeCents,
      mediator?.merchantName ?? "MEDIADOR",
      mediator?.merchantCity ?? "SAO PAULO",
    ),
    match,
  };
}

async function handlePixCopy(
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  try {
    const { payload, match } = await createPixForMatch(
      interaction.guildId,
      matchId,
    );
    if (!match.players.includes(interaction.user.id)) {
      await interaction.reply({
        content: "Somente os jogadores desta partida podem copiar o Pix.",
        ephemeral: true,
      });
      return;
    }
    await interaction.reply({
      content: `Pix Copia e Cola — ${formatBRL(match.stakeCents + match.feeCents)}\n\`\`\`\n${payload}\n\`\`\``,
      ephemeral: true,
    });
  } catch (error) {
    await interaction.reply({ content: publicError(error), ephemeral: true });
  }
}

async function handlePaymentConfirm(
  client: Client,
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  const result = await updateGuildState(interaction.guildId, (state) => {
    const match = state.matches[matchId];
    if (!match || match.status !== "waiting_payment") {
      return { error: "O pagamento desta partida não está aberto." };
    }
    if (!match.players.includes(interaction.user.id)) {
      return { error: "Somente os jogadores desta partida podem confirmar." };
    }
    if (match.paidBy.includes(interaction.user.id)) {
      return { error: "Você já informou que pagou." };
    }
    match.paidBy.push(interaction.user.id);
    const allPaid = match.paidBy.length === match.players.length;
    if (allPaid) match.status = "verifying_payment";
    return {
      match: { ...match, paidBy: [...match.paidBy] },
      allPaid,
    };
  });
  if ("error" in result && result.error) {
    await interaction.reply({ content: result.error, ephemeral: true });
    return;
  }
  if (!("match" in result) || !result.match) return;
  await interaction.reply({
    content: result.allPaid
      ? "Todos os jogadores informaram o pagamento. O mediador precisa conferir o recebimento antes de enviar a sala."
      : "Sua confirmação de pagamento foi registrada. O mediador ainda precisa conferir o recebimento.",
    ephemeral: true,
  });
  if (result.allPaid && result.match.threadId) {
    const thread = await client.channels.fetch(result.match.threadId).catch(() => null);
    if (thread?.isThread()) {
      await thread.send(
        `<@${result.match.moderatorId}> Todos os jogadores informaram o pagamento. Confira o recebimento e confirme abaixo antes de enviar o ID e a senha da sala.`,
      );
      await thread.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xe6a23c)
            .setTitle("Conferência dos pagamentos")
            .setDescription(
              "As confirmações dos jogadores não verificam o recebimento. Confira o seu banco e só então confirme.",
            ),
        ],
        components: verifyPaymentButton(matchId),
      });
    }
  }
}

async function handlePaymentVerify(
  client: Client,
  interaction: ButtonInteraction,
  matchId: string,
): Promise<void> {
  assertGuild(interaction);
  const updated = await updateGuildState(interaction.guildId, (state) => {
    const match = state.matches[matchId];
    if (
      !match ||
      match.status !== "verifying_payment" ||
      match.moderatorId !== interaction.user.id
    ) {
      return {
        error: "Somente o mediador atribuído pode confirmar os pagamentos.",
      };
    }
    match.status = "paid";
    return { match: { ...match } };
  });
  if ("error" in updated && updated.error) {
    await interaction.reply({ content: updated.error, ephemeral: true });
    return;
  }
  if (!("match" in updated) || !updated.match) return;
  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0x1ca875)
        .setTitle("Pagamentos conferidos")
        .setDescription(
          "O mediador confirmou o recebimento. Envie no tópico o ID e a senha da sala.",
        ),
    ],
    components: [],
  });
  if (updated.match.threadId) {
    const thread = await client.channels
      .fetch(updated.match.threadId)
      .catch(() => null);
    if (thread?.isThread()) {
      await thread.send(
        `<@${interaction.user.id}> Pagamentos conferidos. Envie agora o ID e a senha da sala.`,
      );
    }
  }
}

async function handleRoomCopy(
  interaction: ButtonInteraction,
  matchId: string,
  field: "id" | "password",
): Promise<void> {
  assertGuild(interaction);
  const state = await readGuildState(interaction.guildId);
  const match = state.matches[matchId];
  if (!match || !match.players.includes(interaction.user.id)) {
    await interaction.reply({
      content: "Somente os jogadores desta partida podem copiar estes dados.",
      ephemeral: true,
    });
    return;
  }
  const value = field === "id" ? match.roomId : match.roomPassword;
  if (!value) {
    await interaction.reply({
      content: "Os dados da sala ainda não foram enviados.",
      ephemeral: true,
    });
    return;
  }
  await interaction.reply({
    content: `${field === "id" ? "ID" : "Senha"} da sala: \`${value}\``,
    ephemeral: true,
  });
}

async function handleRankingCommand(
  interaction: Interaction & { guildId: string },
): Promise<void> {
  if (!interaction.isChatInputCommand()) return;
  await interaction.reply({
    embeds: [rankingMenuEmbed()],
    components: rankingMenuButtons(),
  });
}

async function handleRankingButton(
  interaction: ButtonInteraction,
  action: string[],
): Promise<void> {
  assertGuild(interaction);
  const state = await readGuildState(interaction.guildId);
  if (action[0] === "profile") {
    const stats =
      state.stats[interaction.user.id] ??
      getOrCreateStats(createDefaultGuildState(), interaction.user.id);
    await interaction.reply({
      embeds: [profileEmbed(interaction.user.globalName ?? interaction.user.username, stats)],
      ephemeral: true,
    });
    return;
  }
  if (action[0] === "menu") {
    await interaction.update({
      embeds: [rankingMenuEmbed()],
      components: rankingMenuButtons(),
    });
    return;
  }
  let page = 0;
  if (action[0] === "next") page = Number(action[1] ?? "0") + 1;
  if (action[0] === "prev") page = Number(action[1] ?? "0") - 1;
  const ranked = Object.values(state.stats).filter((stats) => stats.games > 0);
  const lastPage = Math.max(0, Math.ceil(ranked.length / 10) - 1);
  page = Math.min(lastPage, Math.max(0, page));
  await interaction.update({
    embeds: [rankingEmbed(state, interaction.user.id, page)],
    components: rankingPageButtons(page, ranked.length),
  });
}

async function handleMediatorDmControls(
  interaction: ButtonInteraction,
  parts: string[],
): Promise<void> {
  const action = parts[1];
  const guildId = parts[2];
  const matchId = parts[3];
  if (!guildId || !matchId) {
    await interaction.reply({ content: "Controles inválidos.", ephemeral: true });
    return;
  }
  const state = await readGuildState(guildId);
  const match = state.matches[matchId];
  if (!match || match.moderatorId !== interaction.user.id) {
    await interaction.reply({
      content: "Somente o mediador selecionado pode usar estes controles.",
      ephemeral: true,
    });
    return;
  }

  if (action === "winner") {
    if (!["room_ready", "completed"].includes(match.status)) {
      await interaction.reply({
        content: "Registre o resultado depois que a sala for criada.",
        ephemeral: true,
      });
      return;
    }
    await interaction.update({
      content: "Escolha a equipe vencedora:",
      embeds: [],
      components: [winnerSelect(guildId, match)],
    });
    return;
  }

  if (action === "finish") {
    await updateGuildState(guildId, (guildState) => {
      const current = guildState.matches[matchId];
      if (current) current.status = "closed";
    });
    await interaction.update({
      content: "Partida encerrada. O tópico será excluído.",
      embeds: [],
      components: [],
    });
    if (match.threadId) {
      const thread = await interaction.client.channels
        .fetch(match.threadId)
        .catch(() => null);
      if (thread?.isThread()) {
        await thread.delete("Partida encerrada pelo mediador").catch((error) => {
          logger.warn({ err: error }, "Could not delete finished match thread");
        });
      }
    }
    return;
  }

  if (action === "rematch") {
    if (match.status !== "completed") {
      await interaction.reply({
        content: "A revanche fica disponível depois de registrar o ganhador.",
        ephemeral: true,
      });
      return;
    }
    try {
      const newMatch = await createRematch(interaction.client, guildId, match);
      await interaction.update({
        content: `Revanche criada. Os jogadores precisam confirmar novamente no novo tópico <#${newMatch.threadId}>.`,
        embeds: [],
        components: [],
      });
    } catch (error) {
      await interaction.reply({
        content: publicError(error),
        ephemeral: true,
      });
    }
  }
}

async function recordMatchWinner(
  guildId: string,
  matchId: string,
  moderatorId: string,
  winnerTeam: "a" | "b",
): Promise<{ error: string } | { match: MatchRecord }> {
  return updateGuildState(guildId, (state) => {
    const match = state.matches[matchId];
    if (!match || match.moderatorId !== moderatorId) {
      return { error: "Somente o mediador pode registrar o resultado." };
    }
    if (!["room_ready", "completed"].includes(match.status)) {
      return { error: "A partida ainda não pode receber um resultado." };
    }
    if (match.winnerTeam) return { error: "O ganhador já foi registrado." };

    const firstTeam = match.players.slice(0, match.size);
    const secondTeam = match.players.slice(match.size);
    const winners = winnerTeam === "a" ? firstTeam : secondTeam;
    const losers = winnerTeam === "a" ? secondTeam : firstTeam;
    for (const userId of winners) {
      const stats = getOrCreateStats(state, userId);
      stats.games += 1;
      stats.wins += 1;
      stats.coins += 1;
      stats.currentStreak += 1;
      stats.bestStreak = Math.max(stats.bestStreak, stats.currentStreak);
    }
    for (const userId of losers) {
      const stats = getOrCreateStats(state, userId);
      stats.games += 1;
      stats.losses += 1;
      stats.currentStreak = 0;
    }
    match.winnerTeam = winnerTeam;
    match.status = "completed";
    return { match: { ...match } };
  });
}

async function publishMatchResult(
  client: Client,
  match: MatchRecord,
  winnerTeam: "a" | "b",
): Promise<void> {
  const thread = match.threadId
    ? await client.channels.fetch(match.threadId).catch(() => null)
    : null;
  if (thread?.isThread()) {
    await thread.send({ embeds: [matchResultEmbed(match, winnerTeam)] });
  }
}

async function handleWinnerSelect(
  interaction: StringSelectMenuInteraction,
  guildId: string,
  matchId: string,
): Promise<void> {
  const winnerTeam = interaction.values[0];
  if (winnerTeam !== "a" && winnerTeam !== "b") {
    await interaction.reply({ content: "Equipe inválida.", ephemeral: true });
    return;
  }
  const result = await recordMatchWinner(
    guildId,
    matchId,
    interaction.user.id,
    winnerTeam,
  );
  if ("error" in result && result.error) {
    await interaction.reply({ content: result.error, ephemeral: true });
    return;
  }
  if (!("match" in result) || !result.match) return;
  await publishMatchResult(interaction.client, result.match, winnerTeam);
  await interaction.update({
    content: "Resultado registrado. Vitórias, derrotas e coins foram atualizados.",
    components: [],
    embeds: [],
  });
}

async function createRematch(
  client: Client,
  guildId: string,
  source: MatchRecord,
): Promise<MatchRecord> {
  const newId = randomUUID();
  const rematch = await updateGuildState(guildId, (state) => {
    const parentChannelId =
      state.settings.topicChannelId ?? source.parentChannelId;
    const match: MatchRecord = {
      ...source,
      id: newId,
      threadId: null,
      parentChannelId,
      confirmedBy: [],
      paidBy: [],
      moderatorId: null,
      status: "confirming",
      roomId: null,
      roomPassword: null,
      createdAt: Date.now(),
      winnerTeam: null,
      feeCents: state.settings.feeCents,
    };
    state.matches[newId] = match;
    return { ...match };
  });
  await startMatchThread(client, guildId, newId, rematch);
  const state = await readGuildState(guildId);
  return state.matches[newId] ?? rematch;
}

async function handleRoomMessage(
  client: Client,
  message: Message,
): Promise<void> {
  if (!message.guildId || !message.channel.isThread() || !message.content.trim()) {
    return;
  }
  const parts = message.content.trim().split(/\s+/);
  if (parts.length !== 2) return;
  const [roomId, roomPassword] = parts;
  const result = await saveRoomCredentials(
    message.channel,
    message.guildId,
    message.author.id,
    roomId ?? "",
    roomPassword ?? "",
  );
  if (!result.ok) {
    if (result.error) await message.reply(result.error);
    return;
  }
  await message.delete().catch((error) => {
    logger.warn({ err: error }, "Could not delete room credentials message");
  });
}

async function saveRoomCredentials(
  thread: AnyThreadChannel,
  guildId: string,
  userId: string,
  roomId: string,
  roomPassword: string,
): Promise<{ ok: boolean; error?: string }> {
  if (
    !/^\d{2,24}$/.test(roomId) ||
    !/^\d{1,3}$/.test(roomPassword) ||
    Number(roomPassword) < 1 ||
    Number(roomPassword) > 100
  ) {
    return {
      ok: false,
      error:
        "Formato inválido. Informe um ID numérico e uma senha entre 1 e 100.",
    };
  }
  const state = await readGuildState(guildId);
  const match = Object.values(state.matches).find(
    (candidate) => candidate.threadId === thread.id,
  );
  if (!match || match.moderatorId !== userId) {
    return {
      ok: false,
      error: "Somente o mediador atribuído pode enviar os dados desta sala.",
    };
  }
  if (match.status !== "paid") {
    return {
      ok: false,
      error:
        "A sala só pode ser enviada depois que o mediador confirmar o recebimento dos pagamentos.",
    };
  }
  const updated = await updateGuildState(guildId, (guildState) => {
    const current = guildState.matches[match.id];
    if (
      !current ||
      current.status !== "paid" ||
      current.moderatorId !== userId ||
      current.threadId !== thread.id
    ) {
      return false;
    }
    current.roomId = roomId;
    current.roomPassword = roomPassword;
    current.status = "room_ready";
    return true;
  });
  if (!updated) {
    return {
      ok: false,
      error: "O estado da partida mudou. Verifique o tópico e tente novamente.",
    };
  }
  await thread.send({
    content:
      "✅ **Sala criada.** Use os botões abaixo para copiar o ID ou a senha. Depois, registre o vencedor com `.v @usuário`.",
    components: roomButtons(match.id),
  });
  return { ok: true };
}

async function handlePrefixV(client: Client, message: Message): Promise<void> {
  if (!message.guildId || !message.channel.isThread()) return;
  const state = await readGuildState(message.guildId);
  const match = Object.values(state.matches).find(
    (candidate) => candidate.threadId === message.channelId,
  );
  if (!match || match.moderatorId !== message.author.id) return;

  if (message.mentions.users.size > 1) {
    await message.reply("Mencione apenas um jogador: `.v @usuário`.");
    return;
  }
  const mentionedWinner = message.mentions.users.first();
  if (mentionedWinner) {
    if (match.status !== "room_ready" && match.status !== "completed") {
      await message.reply(
        "A vitória só pode ser registrada depois que a sala for criada.",
      );
      return;
    }
    const playerIndex = match.players.indexOf(mentionedWinner.id);
    if (playerIndex < 0) {
      await message.reply("O usuário mencionado não está nesta partida.");
      return;
    }
    const winnerTeam = playerIndex < match.size ? "a" : "b";
    const result = await recordMatchWinner(
      message.guildId,
      match.id,
      message.author.id,
      winnerTeam,
    );
    if ("error" in result) {
      await message.reply(result.error);
      return;
    }
    await publishMatchResult(client, result.match, winnerTeam);
    await message.reply(
      `✅ Ponto registrado para <@${mentionedWinner.id}>. A vitória foi atribuída à equipe ${winnerTeam === "a" ? "1" : "2"}.`,
    );
    return;
  }

  if (match.status !== "room_ready" && match.status !== "completed") {
    await message.reply(
      "A sala ainda não foi criada. Depois, use `.v @usuário` para registrar o vencedor.",
    );
    return;
  }
  try {
    await message.author.send({
      content: `Controles privados da partida ${queueSizeLabels[match.size]} ${platformLabels[match.platform]}. Para registrar a vitória no tópico, use \`.v @usuário\` (em equipes, mencione alguém da equipe vencedora).`,
      components: matchControlButtons(message.guildId, match.id),
    });
    await message.react("✅").catch(() => undefined);
  } catch {
    await message.reply(
      "Não consegui enviar os controles por mensagem privada. Ative mensagens diretas e tente `.v` novamente.",
    );
  }
}

async function handleMessage(client: Client, message: Message): Promise<void> {
  if (message.author.bot || !message.guildId) return;
  if (/^\.v(?:\s|$)/i.test(message.content.trim())) {
    await handlePrefixV(client, message);
    return;
  }
  await handleRoomMessage(client, message);
}

async function handleConfigButton(
  interaction: ButtonInteraction,
  parts: string[],
): Promise<void> {
  const platform = parts[2];
  const amounts = parts.slice(3, 6).map(Number);
  const channelId = parts[6];
  if (
    !platform ||
    !isPlatform(platform) ||
    amounts.length !== 3 ||
    amounts.some((amount) => !Number.isSafeInteger(amount) || amount <= 0) ||
    !channelId
  ) {
    await interaction.reply({
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Configuração inválida",
          "Execute novamente /config-mob, /config-emu ou /config-misto.",
          0xe14754,
        ),
      ],
    });
    return;
  }
  assertGuild(interaction);
  if (!(await requireAdmin(interaction))) return;
  const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
  if (!(channel instanceof TextChannel)) {
    await interaction.reply({
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Canal indisponível",
          "O canal onde você iniciou a configuração não está mais disponível.",
          0xe14754,
        ),
      ],
    });
    return;
  }

  const values = {
    1: amounts[0]!,
    2: amounts[1]!,
    3: amounts[2]!,
  } satisfies Record<QueueSize, number>;
  await interaction.deferUpdate();
  try {
    await publishConfiguredPanels(interaction.guildId, channel, platform, values);
    await interaction.editReply({
      flags: MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Painéis publicados",
          `Os três painéis de ${platformLabels[platform]} foram publicados em ordem decrescente de valor.`,
          0x1ca875,
        ),
      ],
    });
  } catch (error) {
    await interaction.editReply({
      flags: MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Não foi possível publicar",
          publicError(error),
          0xe14754,
        ),
      ],
    });
  }
}

async function handleButton(
  client: Client,
  interaction: ButtonInteraction,
): Promise<void> {
  const parts = interaction.customId.split(":");
  const [scope, action, ...rest] = parts;

  if (scope === "configv2") {
    await handleAdminPanelButton(interaction, action ?? "", rest);
    return;
  }
  if (scope === "queue" && (action === "join" || action === "leave")) {
    await handleQueueButton(
      client,
      interaction,
      action === "leave" ? "leave" : rest[0] ?? "normal",
    );
    return;
  }
  if (scope === "config" && action === "cancel") {
    await interaction.update({
      flags: MessageFlags.IsComponentsV2,
      components: [
        configNoticeContainer(
          "Configuração cancelada",
          "Nenhuma alteração de valores foi publicada.",
          0x777777,
        ),
      ],
    });
    return;
  }
  if (scope === "config" && action === "publish") {
    await handleConfigButton(interaction, parts);
    return;
  }
  if (scope === "match" && action === "confirm" && rest[0]) {
    await completeConfirmations(client, interaction, rest[0]);
    return;
  }
  if (scope === "match" && action === "cancel" && rest[0]) {
    await handleMatchCancel(interaction, rest[0]);
    return;
  }
  if (scope === "mediator" && (action === "join" || action === "leave")) {
    await handleMediatorToggle(client, interaction, action === "join");
    return;
  }
  if (scope === "pix" && action === "register") {
    if (!(await requireMediator(interaction))) return;
    const modal = new ModalBuilder()
      .setCustomId("pix-key")
      .setTitle("Cadastrar chave Pix");
    const input = new TextInputBuilder()
      .setCustomId("pix_key")
      .setLabel("Sua chave Pix")
      .setPlaceholder("CPF, e-mail, telefone ou chave aleatória")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(77);
    const nameInput = new TextInputBuilder()
      .setCustomId("merchant_name")
      .setLabel("Nome que aparece no Pix (até 25 bytes)")
      .setPlaceholder("Nome do recebedor")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(25);
    const cityInput = new TextInputBuilder()
      .setCustomId("merchant_city")
      .setLabel("Cidade que aparece no Pix (até 15 bytes)")
      .setPlaceholder("Cidade")
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(15);
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(input),
      new ActionRowBuilder<TextInputBuilder>().addComponents(nameInput),
      new ActionRowBuilder<TextInputBuilder>().addComponents(cityInput),
    );
    await interaction.showModal(modal);
    return;
  }
  if (scope === "pix" && action === "release" && rest[0]) {
    await handlePixRelease(client, interaction, rest[0]);
    return;
  }
  if (scope === "pix" && action === "copy" && rest[0]) {
    await handlePixCopy(interaction, rest[0]);
    return;
  }
  if (scope === "payment" && action === "confirm" && rest[0]) {
    await handlePaymentConfirm(client, interaction, rest[0]);
    return;
  }
  if (scope === "payment" && action === "verify" && rest[0]) {
    await handlePaymentVerify(client, interaction, rest[0]);
    return;
  }
  if (scope === "room" && (action === "copyid" || action === "copypass") && rest[0]) {
    await handleRoomCopy(
      interaction,
      rest[0],
      action === "copyid" ? "id" : "password",
    );
    return;
  }
  if (scope === "ranking") {
    await handleRankingButton(interaction, [action ?? "", ...rest]);
    return;
  }
  if (scope === "v" && (action === "finish" || action === "winner" || action === "rematch")) {
    await handleMediatorDmControls(interaction, parts);
  }
}

async function handleSelectMenu(
  interaction: StringSelectMenuInteraction,
): Promise<void> {
  const parts = interaction.customId.split(":");
  if (parts[0] === "v" && parts[1] === "winner-select" && parts[2] && parts[3]) {
    await handleWinnerSelect(interaction, parts[2], parts[3]);
  }
}

async function handleSlashCommand(
  client: Client,
  interaction: Interaction,
): Promise<void> {
  if (!interaction.isChatInputCommand()) return;
  const { commandName } = interaction;

  if (commandName === "config-fila") {
    assertGuild(interaction);
    await handleConfigFila(interaction);
    return;
  }
  const platform = parsePlatformCommand(commandName);
  if (platform) {
    assertGuild(interaction);
    await handlePriceConfig(interaction, platform);
    return;
  }
  if (commandName === "fila") {
    assertGuild(interaction);
    await handleFilaCommand(interaction);
    return;
  }
  if (commandName === "config-pix") {
    assertGuild(interaction);
    await handlePixCommand(interaction);
    return;
  }
  if (commandName === "painel") {
    assertGuild(interaction);
    await handleMediatorPanel(interaction);
    return;
  }
  if (commandName === "ranking") {
    assertGuild(interaction);
    await handleRankingCommand(interaction);
    return;
  }
}

async function handleInteraction(
  client: Client,
  interaction: Interaction,
): Promise<void> {
  if (interaction.isChatInputCommand()) {
    await handleSlashCommand(client, interaction);
    return;
  }
  if (interaction.isModalSubmit()) {
    if (interaction.customId.startsWith("prices:")) {
      assertGuild(interaction);
      await handlePriceModal(interaction);
    } else if (interaction.customId.startsWith("configv2:")) {
      assertGuild(interaction);
      await handleConfigSettingModal(interaction);
    } else if (interaction.customId === "pix-key") {
      assertGuild(interaction);
      await handlePixModal(interaction);
    }
    return;
  }
  if (interaction.isButton()) {
    await handleButton(client, interaction);
    return;
  }
  if (interaction.isChannelSelectMenu()) {
    if (interaction.customId === "configv2:channel") {
      await handleConfigChannelSelect(interaction);
    }
    return;
  }
  if (interaction.isStringSelectMenu()) {
    await handleSelectMenu(interaction);
  }
}

function bindDiscordEvents(client: Client, token: string): void {
  client.once(Events.ClientReady, (readyClient) => {
    void (async () => {
      try {
        const rest = new REST({ version: "10" }).setToken(token);
        await rest.put(Routes.applicationCommands(readyClient.user.id), {
          body: discordCommands,
        });
        logger.info(
          { botUserId: readyClient.user.id, commands: discordCommands.length },
          "Discord bot connected and commands synchronized",
        );
      } catch (error) {
        logger.error({ err: error }, "Could not synchronize Discord commands");
      }
    })();
  });

  client.on(Events.InteractionCreate, (interaction) => {
    void handleInteraction(client, interaction).catch(async (error: unknown) => {
      logger.error({ err: error }, "Discord interaction failed");
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction
          .reply({
            content: publicError(error),
            ephemeral: true,
          })
          .catch(() => undefined);
      }
    });
  });

  client.on(Events.MessageCreate, (message) => {
    void handleMessage(client, message).catch((error: unknown) => {
      logger.error({ err: error }, "Discord message handling failed");
    });
  });

  client.on(Events.Error, (error) => {
    logger.error({ err: error }, "Discord client error");
  });
}

export async function startDiscordBot(): Promise<Client> {
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    throw new Error(
      "DISCORD_BOT_TOKEN is missing. Add the bot token in Replit Secrets.",
    );
  }
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });
  bindDiscordEvents(client, token);

  try {
    await client.login(token);
    return client;
  } catch (error) {
    const disallowedIntent =
      error instanceof Error && error.message.includes("Used disallowed intents");
    if (!disallowedIntent) throw error;

    client.destroy();
    logger.warn(
      "Discord Message Content Intent is disabled. Starting slash-command mode; enable the intent in the Discord Developer Portal for .v and ID/senha messages.",
    );
    const slashOnlyClient = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
    });
    bindDiscordEvents(slashOnlyClient, token);
    await slashOnlyClient.login(token);
    return slashOnlyClient;
  }
}