import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import QRCode from "qrcode";

function encryptionKey(): Buffer {
  const botToken = process.env["DISCORD_BOT_TOKEN"];
  if (!botToken) {
    throw new Error("DISCORD_BOT_TOKEN is required to protect Pix keys.");
  }
  return createHash("sha256")
    .update("discord-queue-bot/pix-key/v1\0")
    .update(botToken)
    .digest();
}

export function encryptPixKey(plainText: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([
    cipher.update(plainText, "utf8"),
    cipher.final(),
  ]);
  return [
    "v1",
    iv.toString("base64url"),
    cipher.getAuthTag().toString("base64url"),
    encrypted.toString("base64url"),
  ].join(".");
}

export function decryptPixKey(cipherText: string): string {
  const [version, iv, tag, data] = cipherText.split(".");
  if (version !== "v1" || !iv || !tag || !data) {
    throw new Error("A chave Pix salva está inválida. Cadastre-a novamente.");
  }
  try {
    const decipher = createDecipheriv(
      "aes-256-gcm",
      encryptionKey(),
      Buffer.from(iv, "base64url"),
    );
    decipher.setAuthTag(Buffer.from(tag, "base64url"));
    return Buffer.concat([
      decipher.update(Buffer.from(data, "base64url")),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    throw new Error(
      "Não foi possível abrir a chave Pix. Cadastre-a novamente; isso pode ocorrer após a troca do token do bot.",
    );
  }
}

function tlv(id: string, value: string): string {
  const byteLength = Buffer.byteLength(value, "utf8");
  if (byteLength > 99) throw new Error("Campo Pix excede o limite permitido.");
  return `${id}${String(byteLength).padStart(2, "0")}${value}`;
}

function crc16Ccitt(value: string): string {
  let crc = 0xffff;
  for (const byte of Buffer.from(value, "utf8")) {
    crc ^= byte << 8;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc & 0x8000) !== 0 ? (crc << 1) ^ 0x1021 : crc << 1;
      crc &= 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

export function createPixPayload(
  pixKey: string,
  amountCents: number,
  merchantName = "MEDIADOR",
  merchantCity = "SAO PAULO",
): string {
  if (!pixKey.trim() || Buffer.byteLength(pixKey, "utf8") > 77) {
    throw new Error("A chave Pix precisa ter entre 1 e 77 bytes.");
  }
  if (
    !merchantName.trim() ||
    Buffer.byteLength(merchantName, "utf8") > 25 ||
    !merchantCity.trim() ||
    Buffer.byteLength(merchantCity, "utf8") > 15
  ) {
    throw new Error("Confira o nome do recebedor e a cidade cadastrados no Pix.");
  }
  if (!Number.isSafeInteger(amountCents) || amountCents < 1) {
    throw new Error("O valor Pix precisa ser maior que zero.");
  }

  const amount = (amountCents / 100).toFixed(2);
  const merchantAccount =
    tlv("00", "BR.GOV.BCB.PIX") + tlv("01", pixKey.trim());
  const additionalData = tlv("05", "***");
  const payload =
    tlv("00", "01") +
    tlv("26", merchantAccount) +
    tlv("52", "0000") +
    tlv("53", "986") +
    tlv("54", amount) +
    tlv("58", "BR") +
    tlv("59", merchantName.trim().toLocaleUpperCase("pt-BR")) +
    tlv("60", merchantCity.trim().toLocaleUpperCase("pt-BR")) +
    tlv("62", additionalData) +
    "6304";
  return `${payload}${crc16Ccitt(payload)}`;
}

export async function createPixQrCode(payload: string): Promise<Buffer> {
  return QRCode.toBuffer(payload, {
    type: "png",
    errorCorrectionLevel: "M",
    margin: 2,
    width: 420,
  });
}

export function parseBrazilianMoneyToCents(value: string): number | null {
  const normalized = value.trim().replace(",", ".");
  if (!/^\d{1,7}(?:\.\d{1,2})?$/.test(normalized)) return null;
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount <= 0) return null;
  return Math.round(amount * 100);
}

export function formatBRL(cents: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(cents / 100);
}