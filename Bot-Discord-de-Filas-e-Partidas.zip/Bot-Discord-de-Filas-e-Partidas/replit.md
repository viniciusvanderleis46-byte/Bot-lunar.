# Bot Discord de Filas e Partidas

Bot para filas de Free Fire no Discord: publica filas Mobile, Emulador e Misto, cria tópicos privados para partidas, coordena mediadores, gera QR Pix e mantém perfil/ranking por servidor.

## Executar

- `pnpm --filter @workspace/api-server run dev` — inicia a API e o bot Discord.
- `pnpm --filter @workspace/api-server run typecheck` — verifica os tipos do serviço.
- `pnpm --filter @workspace/db run push` — aplica alterações de schema no banco de desenvolvimento.
- `pnpm run typecheck` — verifica os pacotes do workspace.

Secret obrigatória: `DISCORD_BOT_TOKEN`. O projeto usa o PostgreSQL provisionado pelo Replit.

## Configuração do aplicativo Discord

1. Crie uma aplicação e um bot no Discord Developer Portal e salve o token em Replit Secrets como `DISCORD_BOT_TOKEN`.
2. Ative **Message Content Intent** para o comando `.v` e para o mediador enviar `ID senha`.
3. Convide o bot com os escopos `bot` e `applications.commands`. Permissões necessárias: ver/enviar mensagens, gerenciar mensagens, embeds, anexos, criar/gerenciar tópicos privados, adicionar membros aos tópicos e usar comandos de aplicação.
4. Crie um cargo com “mediador” no nome e atribua-o aos mediadores. Administradores também podem cadastrar chave Pix e operar a escala.
5. Os comandos globais podem levar alguns minutos para aparecer depois que o bot conectar.

## Comandos

- `/config-fila` — abre um painel privado em Components V2 para o administrador editar taxa, imagem, canal de tópicos e valores por plataforma.
- `/config-mob`, `/config-emu`, `/config-misto` — coletam os valores por jogador para 1x1, 2x2 e 3x3; a confirmação também aparece em um painel Components V2 antes de publicar os três painéis.
- `/fila 1x1 plataforma: Mobile|Emulador|Misto` — publica um painel individual; também existem as opções 2x2 e 3x3.
- `/config-pix` — publica uma mensagem para todos com o botão de cadastro; a chave é digitada em formulário privado e criptografada no banco.
- `/painel mediador` — publica o painel público em Components V2. O mediador entra ou sai da escala; somente ativos com chave cadastrada podem ser sorteados.
- `/ranking` — abre perfil e ranking com páginas de até 10 jogadores.
- O mediador envia `ID senha` no tópico depois de confirmar os pagamentos. A mensagem é removida após o registro; o bot publica apenas os botões privados para copiar cada dado, sem repetir os valores em embed.
- `.v` — no tópico, sem menção abre os controles privados de partida; para registrar o vencedor, use `.v @usuário`. Em partidas de equipe, mencionar um jogador atribui a vitória à equipe dele.

**Message Content Intent** precisa estar ativado para o bot ler `ID senha` e `.v @usuário` no tópico. Sem essa intenção, esses fluxos por mensagem não funcionam. Ative-a no Discord Developer Portal e reinicie o serviço.

Filas aceitam 2 jogadores em 1x1, 4 em 2x2 e 6 em 3x3, todos no mesmo painel e modo de gelo. Para partidas em equipe, os primeiros jogadores formam a equipe 1 e os seguintes a equipe 2.

## Pix e confirmação

O bot monta um QR Code Pix estático e o código “Copia e Cola” usando a chave do mediador selecionado; cada jogador paga o valor configurado mais a taxa. Não há gateway, link hospedado nem webhook de confirmação automática. “Já paguei” é apenas uma declaração do jogador: o mediador deve conferir o recebimento no banco e clicar em **Confirmar recebimento** antes de enviar a sala. Não trate o QR como comprovante.

As chaves Pix são criptografadas com AES-256-GCM usando uma chave derivada do token do bot. Se o token for trocado, os mediadores devem cadastrar as chaves novamente.

## Arquitetura

- O processo do bot roda junto da API em `artifacts/api-server`.
- Configurações, filas, partidas, mediadores e estatísticas são persistidos na tabela `discord_guild_state`, isolados por servidor.
- Comandos e interações: `artifacts/api-server/src/discord`.
- Schema do banco: `lib/db/src/schema/index.ts`.
- O banco de produção recebe mudanças de schema pelo fluxo de Publish do Replit; o comando `push` é apenas para desenvolvimento.