import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const discordGuildStateTable = pgTable("discord_guild_state", {
  guildId: text("guild_id").primaryKey(),
  state: jsonb("state").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});